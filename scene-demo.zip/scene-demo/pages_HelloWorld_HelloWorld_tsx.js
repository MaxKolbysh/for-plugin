"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkmaxtest_scenedemo_app"] = self["webpackChunkmaxtest_scenedemo_app"] || []).push([["pages_HelloWorld_HelloWorld_tsx"],{

/***/ "./pages/HelloWorld/HelloWorld.tsx":
/*!*****************************************!*\
  !*** ./pages/HelloWorld/HelloWorld.tsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _helloWorldScene__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helloWorldScene */ \"./pages/HelloWorld/helloWorldScene.tsx\");\n\n\nconst HelloWorld = ()=>{\n    const scene = (0,_helloWorldScene__WEBPACK_IMPORTED_MODULE_1__.getScene)();\n    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(scene.Component, {\n        model: scene\n    });\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HelloWorld);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9IZWxsb1dvcmxkL0hlbGxvV29ybGQudHN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBMEI7QUFDbUI7QUFFN0MsTUFBTUUsYUFBYTtJQUNqQixNQUFNQyxRQUFRRiwwREFBUUE7SUFFdEIscUJBQU8sMkRBQUNFLE1BQU1DLFNBQVM7UUFBQ0MsT0FBT0Y7O0FBQ2pDO0FBRUEsaUVBQWVELFVBQVVBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9tYXh0ZXN0LXNjZW5lZGVtby1hcHAvLi9wYWdlcy9IZWxsb1dvcmxkL0hlbGxvV29ybGQudHN4PzY3YzUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGdldFNjZW5lIH0gZnJvbSAnLi9oZWxsb1dvcmxkU2NlbmUnO1xuXG5jb25zdCBIZWxsb1dvcmxkID0gKCkgPT4ge1xuICBjb25zdCBzY2VuZSA9IGdldFNjZW5lKCk7XG5cbiAgcmV0dXJuIDxzY2VuZS5Db21wb25lbnQgbW9kZWw9e3NjZW5lfSAvPjtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEhlbGxvV29ybGQ7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJnZXRTY2VuZSIsIkhlbGxvV29ybGQiLCJzY2VuZSIsIkNvbXBvbmVudCIsIm1vZGVsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/HelloWorld/HelloWorld.tsx\n");

/***/ }),

/***/ "./pages/HelloWorld/helloWorldScene.tsx":
/*!**********************************************!*\
  !*** ./pages/HelloWorld/helloWorldScene.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   getScene: () => (/* binding */ getScene)\n/* harmony export */ });\n/* harmony import */ var _grafana_scenes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @grafana/scenes */ \"../node_modules/@grafana/scenes/dist/esm/index.js\");\n\nfunction getScene() {\n    return new _grafana_scenes__WEBPACK_IMPORTED_MODULE_0__.EmbeddedScene({\n        body: new _grafana_scenes__WEBPACK_IMPORTED_MODULE_0__.SceneFlexLayout({\n            children: [\n                new _grafana_scenes__WEBPACK_IMPORTED_MODULE_0__.SceneFlexItem({\n                    width: '100%',\n                    height: 300,\n                    body: _grafana_scenes__WEBPACK_IMPORTED_MODULE_0__.PanelBuilders.text().setTitle('Hello world panel').setOption('content', 'Hello world!').build()\n                })\n            ]\n        })\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9IZWxsb1dvcmxkL2hlbGxvV29ybGRTY2VuZS50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBK0Y7QUFFeEYsU0FBU0k7SUFDZCxPQUFPLElBQUlKLDBEQUFhQSxDQUFDO1FBQ3ZCSyxNQUFNLElBQUlKLDREQUFlQSxDQUFDO1lBQ3hCSyxVQUFVO2dCQUNSLElBQUlKLDBEQUFhQSxDQUFDO29CQUNoQkssT0FBTztvQkFDUEMsUUFBUTtvQkFDUkgsTUFBTUYsMERBQWFBLENBQUNNLElBQUksR0FBR0MsUUFBUSxDQUFDLHFCQUFxQkMsU0FBUyxDQUFDLFdBQVcsZ0JBQWdCQyxLQUFLO2dCQUNyRzthQUNEO1FBQ0g7SUFDRjtBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbWF4dGVzdC1zY2VuZWRlbW8tYXBwLy4vcGFnZXMvSGVsbG9Xb3JsZC9oZWxsb1dvcmxkU2NlbmUudHN4P2VmOTciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRW1iZWRkZWRTY2VuZSwgU2NlbmVGbGV4TGF5b3V0LCBTY2VuZUZsZXhJdGVtLCBQYW5lbEJ1aWxkZXJzIH0gZnJvbSAnQGdyYWZhbmEvc2NlbmVzJztcblxuZXhwb3J0IGZ1bmN0aW9uIGdldFNjZW5lKCkge1xuICByZXR1cm4gbmV3IEVtYmVkZGVkU2NlbmUoe1xuICAgIGJvZHk6IG5ldyBTY2VuZUZsZXhMYXlvdXQoe1xuICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgbmV3IFNjZW5lRmxleEl0ZW0oe1xuICAgICAgICAgIHdpZHRoOiAnMTAwJScsXG4gICAgICAgICAgaGVpZ2h0OiAzMDAsXG4gICAgICAgICAgYm9keTogUGFuZWxCdWlsZGVycy50ZXh0KCkuc2V0VGl0bGUoJ0hlbGxvIHdvcmxkIHBhbmVsJykuc2V0T3B0aW9uKCdjb250ZW50JywgJ0hlbGxvIHdvcmxkIScpLmJ1aWxkKCksXG4gICAgICAgIH0pLFxuICAgICAgXSxcbiAgICB9KSxcbiAgfSk7XG59XG4iXSwibmFtZXMiOlsiRW1iZWRkZWRTY2VuZSIsIlNjZW5lRmxleExheW91dCIsIlNjZW5lRmxleEl0ZW0iLCJQYW5lbEJ1aWxkZXJzIiwiZ2V0U2NlbmUiLCJib2R5IiwiY2hpbGRyZW4iLCJ3aWR0aCIsImhlaWdodCIsInRleHQiLCJzZXRUaXRsZSIsInNldE9wdGlvbiIsImJ1aWxkIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/HelloWorld/helloWorldScene.tsx\n");

/***/ })

}]);