<!-- This README file is going to be the one displayed on the Grafana.com website for your plugin -->

# Scenes App Template

A basic template for building Grafana applications with @grafana/scenes.
